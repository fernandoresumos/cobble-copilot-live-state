# Speed Augment workaround for Mystical Agriculture 1.21.1
# 1x Speed III = vanilla Speed III
execute as @a if data entity @s Inventory[{Slot:101b}].components."mysticalagriculture:equipped_augments"[{id:"mysticalagriculture:speed_iii"}] run effect give @s minecraft:speed 2 2 true

# 2x Speed III, one in each Awakened Supremium augment slot = vanilla Speed VI
execute as @a if data entity @s Inventory[{Slot:101b}].components."mysticalagriculture:equipped_augments"[{id:"mysticalagriculture:speed_iii",slot:0}] if data entity @s Inventory[{Slot:101b}].components."mysticalagriculture:equipped_augments"[{id:"mysticalagriculture:speed_iii",slot:1}] run effect give @s minecraft:speed 2 5 true
