MYSTICAL AGRICULTURE SPEED AUGMENT FIX - Minecraft 1.21.1

No setup testado, o jogador usa Awakened Supremium Leggings Tier 5 com dois Speed III.
O datapack detecta o componente mysticalagriculture:equipped_augments na perneira equipada.

Comportamento:
- 1x Speed III: aplica Speed III.
- 2x Speed III nos slots 0 e 1: aplica Speed VI para representar empilhamento.
- Ao tirar a perneira, o efeito expira sozinho em ate 2 segundos.
- Nao exige set completo.
- Server-side: amigos nao precisam instalar nada.

Instalacao:
1. Coloque o ZIP em world/datapacks/
2. Use /reload ou reinicie o servidor.
3. Use /datapack list para confirmar.
